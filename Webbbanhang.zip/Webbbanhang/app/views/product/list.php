<?php include 'app/views/shares/header.php'; ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>📦 Danh sách sản phẩm</h2>
        <a href="/webbanhang/Product/add" class="btn btn-success">+ Thêm sản phẩm mới</a>
    </div>

    <?php if (empty($products)): ?>
        <div class="alert alert-warning">Hiện chưa có sản phẩm nào.</div>
    <?php else: ?>
        <div class="row g-4">
            <?php foreach ($products as $product): ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card shadow-sm h-100">
                        <div class="card-body d-flex flex-column justify-content-between">
                            <div>
                                <h5 class="card-title">
                                    <a href="/webbanhang/Product/show/<?= $product->id; ?>" class="text-decoration-none text-dark">
                                        <?= htmlspecialchars($product->name, ENT_QUOTES, 'UTF-8'); ?>
                                    </a>
                                </h5>
                                <p class="card-text small"><?= htmlspecialchars($product->description, ENT_QUOTES, 'UTF-8'); ?></p>
                                <p class="mb-1">
                                    💰 <strong><?= number_format($product->price, 0, ',', '.'); ?> VNĐ</strong>
                                </p>
                                <p class="mb-0">
                                    🗂️ <strong><?= htmlspecialchars($product->category_name, ENT_QUOTES, 'UTF-8'); ?></strong>
                                </p>
                            </div>
                            <div class="mt-3 d-flex justify-content-between">
                                <a href="/webbanhang/Product/edit/<?= $product->id; ?>" class="btn btn-sm btn-warning">✏️ Sửa</a>
                                <a href="/webbanhang/Product/delete/<?= $product->id; ?>"
                                   class="btn btn-sm btn-danger"
                                   onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này?');">🗑️ Xóa</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php include 'app/views/shares/footer.php'; ?>
