<?php include 'app/views/shares/header.php'; ?>

<div class="container mt-4">
    <h2 class="mb-4">📦 Thêm sản phẩm mới</h2>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php foreach ($errors as $error): ?>
                    <li><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="/webbanhang/Product/save" onsubmit="return validateForm();">
        <div class="row g-3">
            <div class="col-md-6">
                <label for="name" class="form-label">Tên sản phẩm</label>
                <input type="text" id="name" name="name" class="form-control" placeholder="Nhập tên sản phẩm..." required>
            </div>

            <div class="col-md-6">
                <label for="price" class="form-label">Giá (VNĐ)</label>
                <input type="number" id="price" name="price" class="form-control" step="0.01" placeholder="Ví dụ: 120000" required>
            </div>

            <div class="col-md-12">
                <label for="description" class="form-label">Mô tả sản phẩm</label>
                <textarea id="description" name="description" class="form-control" rows="4" placeholder="Nhập mô tả chi tiết..." required></textarea>
            </div>

            <div class="col-md-6">
                <label for="category_id" class="form-label">Danh mục</label>
                <select name="category_id" id="category_id" class="form-select" required>
                    <option value="" disabled selected>-- Chọn danh mục --</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?= $category->id; ?>">
                            <?= htmlspecialchars($category->name, ENT_QUOTES, 'UTF-8'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-12 mt-4">
                <button type="submit" class="btn btn-primary">✔️ Thêm sản phẩm</button>
                <a href="/webbanhang/Product/list" class="btn btn-secondary ms-2">← Quay lại danh sách</a>
            </div>
        </div>
    </form>
</div>

<script>
    function validateForm() {
        const name = document.getElementById('name').value.trim();
        const price = parseFloat(document.getElementById('price').value);
        let errors = [];

        if (name.length < 5 || name.length > 100) {
            errors.push('Tên sản phẩm phải từ 5 đến 100 ký tự.');
        }

        if (isNaN(price) || price <= 0) {
            errors.push('Giá phải là một số dương.');
        }

        if (errors.length > 0) {
            alert(errors.join("\n"));
            return false;
        }

        return true;
    }
</script>

<?php include 'app/views/shares/footer.php'; ?>
