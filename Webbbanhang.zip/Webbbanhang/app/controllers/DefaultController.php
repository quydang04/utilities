<?php
class DefaultController
{
    public function index()
    {
        echo "Welcome to the homepage!";
    }
}
